# Verify my changes

Read AGENTS.md and qa/release-checklist.md. Run npm run verify, then inspect the supplied project at 390 / 768 / 1440 CSS pixel widths if browser tools are available. Check keyboard focus, menu, board/list view, task state, pricing toggle, FAQ, form validation, asset paths and reduced motion. Fix reproducible problems without broad redesign. Report exact checks, remaining limitations and whether any backend or live-service claim is still only a demo.
