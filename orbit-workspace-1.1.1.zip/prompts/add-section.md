# Add a section

Read AGENTS.md and design/section-style-map.md. Ask for the new section's job and real content if not provided. Propose the most useful position, then implement a section using this project's spacing, typography, colors and accessibility patterns. Choose a layout suited to its content instead of copying a neighboring card grid. Update the section map, run npm run verify, and review 390 / 768 / 1440 pixel layouts.
