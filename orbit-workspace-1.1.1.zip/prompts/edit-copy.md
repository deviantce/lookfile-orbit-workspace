# Adapt the copy

Read AGENTS.md, brand-input.json and src/content.ts. Rewrite the page for my audience and language while keeping its current layout and core hierarchy. Keep headlines near their current visual length; allow natural line wrapping. Do not invent logos, testimonials, user counts, performance metrics or guarantees. Preserve the sample/backend scope disclosure unless a real integration has been supplied. Run npm run verify and list any sections whose text length needs visual review.
