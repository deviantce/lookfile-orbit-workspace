# Start with my product

Read AGENTS.md, START-HERE.md, brand-input.json and the design documents. Summarize the supplied product brief and identify missing essentials. Adapt this complete React project to the brief while preserving its design system and responsive behavior. Start with content and brand tokens; do not add a backend or invent proof. Tell me which files changed, run npm run verify, and list the visual checks still needed.
