# Rebrand the project

Read AGENTS.md and brand-input.json. Apply my brand name, tone, accent and calls to action to the existing project. Update design/tokens.css and design/design-tokens.json together. Preserve readable contrast, heading hierarchy, mobile behavior and the separation between fictional demo data and real claims. Avoid replacing the page with a generic layout. Run npm run verify and show the affected sections for review.
