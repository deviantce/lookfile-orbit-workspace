(() => {
 'use strict';
 const data=JSON.parse(document.getElementById('brand-data').textContent);
 const q=(s,r=document)=>r.querySelector(s),qa=(s,r=document)=>[...r.querySelectorAll(s)];
 const announce=text=>{const toast=q('#copy-status');toast.textContent=text;toast.hidden=false;clearTimeout(announce.timer);announce.timer=setTimeout(()=>toast.hidden=true,3500)};
 const menu=q('#menu-toggle'),sidebar=q('.sidebar');
 menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));sidebar.classList.toggle('open',open)});
 const closeMenu=()=>{menu.setAttribute('aria-expanded','false');sidebar.classList.remove('open')};
 qa('#brand-nav a').forEach(a=>a.addEventListener('click',closeMenu));
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sidebar.classList.contains('open')){closeMenu();menu.focus()}});
 const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){qa('#brand-nav a').forEach(a=>{const selected=a.hash===`#${entry.target.id}`;a.classList.toggle('active',selected);if(selected)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current')})}},{rootMargin:'-10% 0px -65% 0px'});
 qa('main section[id]').forEach(s=>observer.observe(s));
 async function copy(text){
  try{if(!navigator.clipboard?.writeText)throw Error('Clipboard unavailable');await navigator.clipboard.writeText(text);announce('Copied to clipboard.');}
  catch{const dialog=q('#copy-dialog'),field=q('#copy-fallback');field.value=text;dialog.showModal();field.focus();field.select();}
 }
 qa('[data-copy]').forEach(button=>button.addEventListener('click',()=>copy(button.dataset.copy)));
 qa('[data-copy-icon]').forEach(button=>button.addEventListener('click',()=>copy(data.icons.assets.find(x=>x.id===button.dataset.copyIcon).svg)));
 q('#specimen-input').addEventListener('input',e=>qa('[data-type-specimen]').forEach(x=>x.textContent=e.target.value||data.description));
 q('#icon-search').addEventListener('input',e=>{const value=e.target.value.trim().toLowerCase();let count=0;qa('[data-icon]').forEach(x=>{const match=x.dataset.icon.toLowerCase().includes(value);x.hidden=!match;if(match)count++});q('#icon-count').textContent=`${count} ${count===1?'icon':'icons'}`;q('#icon-empty').hidden=count>0});
 const action=q('#sample-action');action.addEventListener('click',()=>{const selected=action.getAttribute('aria-pressed')!=='true';action.setAttribute('aria-pressed',String(selected));action.textContent=selected?'Direction selected':'Select this direction';q('#sample-action-state').textContent=selected?'Selected · local specimen':'Not selected'});
 q('#sample-form').addEventListener('submit',e=>{e.preventDefault();q('#sample-feedback').textContent=`“${q('#sample-label').value.trim()}” — ${q('#sample-state').value}. Specimen applied here only; nothing was sent or saved.`});
 q('#focus-example').addEventListener('click',()=>announce('Focus specimen activated. Your place on the page is unchanged.'));
 const mq=matchMedia('(prefers-reduced-motion: reduce)'),staticControl=q('#static-motion');
 let requestedStatic=false;
 const reduced=()=>mq.matches||requestedStatic;
 const cards=qa('[data-motion-card]');
 function state(card,playing,message){card.dataset.playing=String(playing);q('[data-motion="play"]',card).disabled=playing||reduced();q('[data-motion="play"]',card).setAttribute('aria-pressed',String(playing));q('[data-motion="pause"]',card).setAttribute('aria-pressed',String(!playing));q('[data-motion="replay"]',card).setAttribute('aria-pressed','false');q('[data-motion="pause"]',card).disabled=!playing||reduced();q('[data-motion="replay"]',card).disabled=reduced();q('.motion-state',card).textContent=message;}
 function pause(card){const actor=q('.motion-actor',card);actor.style.animationPlayState='paused';state(card,false,reduced()?'Static · reduced motion':'Paused · position retained')}
 function play(card,replay=false){if(reduced())return;const actor=q('.motion-actor',card);if(replay||!actor.classList.contains('is-active')||card.dataset.ended==='true'){actor.classList.remove('is-active');void actor.offsetWidth;actor.classList.add('is-active');card.dataset.ended='false';}actor.style.animationPlayState='running';state(card,true,'Playing');}
 cards.forEach(card=>{qa('[data-motion]',card).forEach(button=>button.addEventListener('click',()=>button.dataset.motion==='pause'?pause(card):play(card,button.dataset.motion==='replay')));q('.motion-actor',card).addEventListener('animationend',()=>{card.dataset.ended='true';state(card,false,'Complete · replay available')})});
 function applyPreference(){document.documentElement.classList.toggle('reduce-motion',reduced());staticControl.checked=reduced();staticControl.disabled=mq.matches;q('#motion-preference-status').textContent=mq.matches?'System reduced motion is active':requestedStatic?'Static previews selected':'Motion studies are manual';cards.forEach(pause);}
 staticControl.addEventListener('change',()=>{requestedStatic=staticControl.checked;applyPreference()});mq.addEventListener('change',applyPreference);q('#pause-all').addEventListener('click',()=>{cards.forEach(pause);announce('All motion studies paused.')});applyPreference();
})();
