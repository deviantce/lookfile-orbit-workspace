# Orbit brand system

This folder contains the standalone brand guide at `index.html`, its full editable data in `brand-system.json`,12 original SVG icons, vector identity variants, CSS tokens and 6 manual motion studies. Open the built website's `/brand/` route or serve this public folder through a local HTTP server. No external service, account or API key is needed.

## Editing map

- `brand-system.json`: source-derived identity, semantic roles, type, geometry, imagery, component guidance, icon source strings and motion records. The page also embeds the data to avoid runtime fetches in the preview sandbox. Keep them synchronized when editing.
- `icons/*.svg`: original editable path geometry, 32×32 viewboxes. Preserve the family stroke width and cap rules.
- `system-*.svg`: identity exports and variants. Existing native `mark.svg`,`wordmark.svg` and any other original assets were preserved.
- `motion.css`: optional animation rules. Add `.is-active` only after a deliberate interaction; use the motion record's duration/easing. Pause with `animation-play-state:paused`. Always retain the reduced-motion override.
- `tokens.css`: a snapshot of the source CSS token declarations. The website authority remains `design/tokens.css` or its documented runtime CSS. Changing this snapshot alone does not rebrand the app.
- `brand.css`: fonts and accessible presentation values for this guide.
- `viewer.css` and `viewer.js`: responsive guide layout and local interactions. No data is sent or stored.
- `asset-ledger.json`: file inventory with origin, license and SHA-256 checksums, excluding itself.

## What is existing and what is new

The site uses a typographic orbit ring and a lowercase system-font wordmark. The outlined Orbit signature and orbit symbol are optional new vector companions; they do not replace the existing page header.

All 12 icons are new original brand extensions. Motion records distinguish adapted existing runtime cues from new optional extensions. None of these additions silently changes the existing website's layout or behavior. New clearspace, minimum-size and semantic-extension specifications are labelled in the data.

The type and spacing tables record CSS declarations; they are not a fresh measurement of every responsive render. Inspect real browser wrapping and every reused crop after an edit.

## Accessibility

Brand-page prose is at least 16px and metadata at least 14px. Actual type specimens may demonstrate smaller original roles, always accompanied by readable specifications. Motion begins paused, supports play/pause/replay and respects operating-system reduced motion. Clipboard permission may be blocked in a sandbox; a selectable-text dialog is provided instead.

Ratios use the standard sRGB luminance calculation for exact flat-color pairs. A passing swatch is not approval of a whole component or page. Keep status labels, visible focus, keyboard actions and useful image descriptions.

## Asset terms

The included LICENSE.md governs original kit material. Font files and underlying outlined glyphs retain their separate OFL notices. System font binaries are not redistributed.

Original brand-system code and assets follow this kit's MIT. No new third-party icon library, proprietary font or source-site asset is included. Existing generated photos remain fictional concepts with their prior provenance. Preserve `ASSET-LICENSES.md` and all applicable font notices when handing off source.
