# Orbit Workspace: AI editing context

Read `START-HERE.md`, `brand-input.json`, `design/DESIGN.md`, `design/section-style-map.md`, and `src/content.ts` before editing. This project is a complete frontend design kit, not a prompt-only product or backend application.

Use React 18, TypeScript, Vite 6 and Tailwind CSS 3. Keep the exact dependency baseline unless the user explicitly requests a framework migration. Do not add libraries for simple CSS or React interactions. Do not assume a hosted agent service, MCP server or API key exists.

Preserve the warm paper background, coral accent, clear editorial hierarchy and accessible interaction patterns unless the user changes the brand brief. Keep runtime tokens and `design/design-tokens.json` synchronized. Prefer `src/content.ts` for repeatable content. Do not invent testimonials, usage metrics, commercial results, credentials or working backend integrations.

Before changing code, briefly state the intended files and user-visible outcome. Apply changes in small reviewable steps. Ask only for essential missing product information; use clearly marked placeholders for optional details.

Validate with `npm run verify`. Review the page at 390, 768 and 1440 CSS pixels; check keyboard navigation, content overflow, FAQ states, board/list controls, reduced motion and form feedback. Report what was checked and what remains uncertain. A successful build is not evidence of live authentication, form delivery or payments.

Never store secrets, production tokens or customer personal data in the project. Never deploy or send messages without the project owner's authorization. When asked to connect a backend, identify the missing API contract and preserve clearly labeled demo behavior until it exists.
