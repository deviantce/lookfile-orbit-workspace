# Section map

| Section | Purpose | Desktop | Mobile |
| --- | --- | --- | --- |
| Sample notice and navigation | Set honest product context | One-line notice, inline links | Notice wraps; keyboard-operable menu |
| Hero | Introduce one promise and action | Centered two-line headline | 44px headline, stacked actions |
| Workspace | Show the product idea through real local interaction | Sidebar and three-card board | No sidebar; stacked cards |
| Features | Explain three jobs | Numbered editorial columns | One column, section dividers |
| Statement | Give the page a distinct visual pause | Full-width coral, serif emphasis | Shorter heading, same clear contrast |
| Pricing | Demonstrate offer structure | Intro beside one offer | Offer below introduction |
| FAQ | Resolve concrete scope questions | Two-column introduction and accordion | Single column |
| Final action | Demonstrate input validation | Inline email field and button | Stacked controls |
| Footer | Close the fictional brand | Compact horizontal row | Two rows |

Pricing is fictional SaaS pricing, not the LOOKFILE kit price. Keep this distinction whenever reusing the sample.
