# Design rules

Orbit is a calm, warm SaaS landing page. Spacious editorial copy surrounds a smaller, believable product interface. Coral emphasizes one action or idea at a time; it is not a background for every section.

Use the existing system font stack, paper `#faf8f3`, ink `#272821`, coral `#ff8a70`, muted text `#68695f`, and line `#dfdfd5`. The text accent uses darker `#c64f38` for readable emphasis on paper. Do not use white body text on coral. Keep normal copy at least 16px, helper copy at least 12px, and interactive controls visibly focusable. Dense fictional app details may be smaller inside the illustrated product preview; do not copy that density into customer forms.

Use 1180px maximum page width, 32px desktop side clearance and 16px mobile clearance. Major headings use tight spacing and short lines; paragraph line height is 1.6–1.75. Cards have a subtle border and 20px outer radius. The embedded workspace uses 9–13px smaller radii.

At 600px or narrower: menu collapses; the fictional workspace sidebar disappears; three board cards stack; pricing, feature, and FAQ columns become one column. Avoid fixed page heights and horizontal page scrolling. The board/list toggle, task checkbox, price switch and FAQ controls remain operable by keyboard.

New sections must have a clear purpose and a different layout when content demands it. Do not append generic card grids by default. Do not invent customer proof. Use the existing coral, sage and lilac CSS shapes instead of hotlinked stock imagery.

There is no entrance animation dependency. Smooth anchor scrolling respects `prefers-reduced-motion`. Any new motion must support that setting.
