# Orbit Workspace — LOOKFILE free sample

A complete, editable **AI-ready Website Kit** for a fictional productivity product. This is a free technical sample of the delivery format, not one of the store's paid catalog concepts.

Start with [START-HERE.md](START-HERE.md). You receive the project, its design context, an **AI Playbook**, and **Project checks**. The playbook is readable Markdown, not a hosted agent, paid API integration, or a guarantee about any model's output.

```sh
npm ci
npm run dev
npm run verify
```

Requires Node 22. `npm run verify` runs TypeScript checks and a production build. The production output is `dist/`; upload that directory to a static web host. Nothing in this kit needs LOOKFILE to stay online.

## What works

Responsive navigation, board/list switching, a task checkbox, a monthly/yearly price toggle, FAQ accordion, and an email validation demo. Every sample interaction is local to the page session. The form sends nothing. There is no authentication, payments, database, real collaboration, or AI API connection.

## What is included

- `src/`, `public/`, configuration and exact dependency lockfile: the complete project.
- `design/`: tokens used by the actual CSS, design rules, section map, asset manifest.
- `AGENTS.md`, `brand-input.json`, `prompts/`: the AI Playbook with five concrete tasks.
- `qa/`, `npm run verify`: Project checks and a human review checklist.
- `LICENSE.md`, `ASSET-LICENSES.md`, `COMPATIBILITY.md`, `CHANGELOG.md`: use and support boundaries.

No `node_modules`, private data, API keys, reference-site assets, internal research, or LOOKFILE storefront backend is bundled.

## Brand system

Open `/brand/` for this release’s visual brand system: SVG identity and icons, semantic colors, type specimens and scale, layout/spacing, components, imagery guidance, and playable motion patterns with reduced-motion support. Editable files live in `public/brand/`. This page is included in the source ZIP and uses local assets.
