# Start here

1. Install Node **22.x**. Confirm `node --version` begins with `v22.`.
2. Extract the ZIP. In the folder containing `package.json`, run `npm ci`.
3. Run `npm run dev` and open the address printed by Vite.
4. Edit `brand-input.json` with your own product, audience and CTA. Keep secrets out of this file.
5. Open this whole folder in your AI coding tool. Give it `prompts/start.md`; ask it to read `AGENTS.md` first.
6. Review every changed screen and run `npm run verify`.
7. Run `npm run build`, then deploy the contents of `dist/` to a static web host.

## Editing map

| Change | File |
| --- | --- |
| Reusable product content and FAQs | `src/content.ts` |
| Hero and section markup; demo interactions | `src/App.tsx` |
| Brand colors and page-wide tokens | `design/tokens.css` |
| Responsive layouts | `src/styles.css` |
| Design intent and section rules | `design/DESIGN.md`, `design/section-style-map.md` |
| AI task instructions | `prompts/` |

The token JSON documents the CSS token values; keep both files synchronized. The CSS is the runtime source of truth. `brand-input.json` is an AI input brief, not a live configuration file: your coding tool applies it to the source.

## Deployment paths

The default `base: './'` in `vite.config.ts` creates relative asset URLs. Root deployment and a directory such as `/my-product/` work for this single-page sample. Always keep a trailing slash when opening a directory deployment.

For a fixed prefix run `npm run build -- --base=/my-product/`. If you introduce client-side routes, configure your router basename and your host's HTML fallback for that exact prefix. The supplied sample uses in-page anchors and has no external router dependency.

## When something fails

Check Node 22, use `npm ci`, and copy the complete error message. Do not delete or regenerate the lockfile as a first fix. Remove only this project's `node_modules` if reinstalling is necessary. No `.env` or API key is required. A completed build is not a substitute for mobile and interaction review; use `qa/release-checklist.md`.
