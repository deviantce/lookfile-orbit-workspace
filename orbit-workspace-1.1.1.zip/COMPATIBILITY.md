# Compatibility record

Baseline: Node 22, React 18.3.1, React DOM 18.3.1, TypeScript 5.7.3, Vite 6.4.3 and Tailwind CSS 3.4.19. This matches the installed LOOKFILE storefront generation baseline; optional storefront libraries are not required by the sample.

The factory records the actual source build and standalone ZIP installation result in `qa/verification.json` when packaging. Read that record for the environment, command and date rather than assuming that file presence means validation passed.

The AI Playbook uses Markdown and JSON files that can be opened by a coding assistant. No per-model editing benchmark has yet been performed. Being able to read these files is not a claim that every editor automatically reads `AGENTS.md`, nor that every model produces identical design changes. Ask your tool to read it explicitly.

The sample is a static frontend. Backend, login, payment, email delivery, hosting subscriptions and model-provider usage are not included. Browser coverage and manual review evidence are recorded separately from the source compilation checks.
