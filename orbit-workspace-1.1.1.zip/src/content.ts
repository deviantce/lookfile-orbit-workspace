export const content = {
  brand: 'orbit',
  eyebrow: 'Less busywork. More good work.',
  title: 'A little more space for your next big idea.',
  description: 'Give your team one calm place to plan projects, share decisions, and move the work that matters forward.',
  primaryCta: 'Explore the workspace',
  email: 'hello@example.com',
  features: [
    { number: '01', title: 'Catch the good ideas.', body: 'A clear home for messy first drafts, small discoveries, and everything worth coming back to.' },
    { number: '02', title: 'Make the next step obvious.', body: 'Turn a conversation into a simple plan. Keep the owner, the decision, and the next task together.' },
    { number: '03', title: 'Keep your own rhythm.', body: 'See what matters today without turning every afternoon into another status meeting.' },
  ],
  faqs: [
    { question: 'Is Orbit a real productivity service?', answer: 'Orbit is a fictional product used in this free LOOKFILE source-code sample. The page is real; accounts, billing and collaboration services are not connected.' },
    { question: 'Can I change the brand with an AI coding tool?', answer: 'Yes. Open the whole project, fill in brand-input.json, and ask your coding tool to read AGENTS.md and the first recipe in prompts/. You review and deploy the resulting code.' },
    { question: 'What is included in this sample?', answer: 'The runnable React project, exact dependency versions and lockfile, design tokens and rules, AI task recipes, asset records, and a release checklist. No API key or LOOKFILE runtime is needed.' },
  ],
}
