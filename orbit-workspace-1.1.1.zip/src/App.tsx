import { useState } from 'react'
import { content } from './content'

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [view, setView] = useState<'Board' | 'List'>('Board')
  const [done, setDone] = useState(false)
  const [yearly, setYearly] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(0)
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)
  const tasks = ['Explore the first direction', 'Make room for feedback', 'Bring the small details together']
  return <>
    <a className="skip-link" href="#main">Skip to content</a>
    <div className="sample-note">LOOKFILE free sample · A fictional product, a real React project.</div>
    <header className="site-header wrap">
      <a className="wordmark" href="#"><span className="brand-orb" aria-hidden="true">✳</span>{content.brand}<span className="wordmark-dot">.</span></a>
      <button className="menu-button" aria-expanded={menuOpen} aria-controls="site-nav" onClick={() => setMenuOpen(!menuOpen)}>Menu <span aria-hidden="true">{menuOpen ? '−' : '+'}</span></button>
      <nav id="site-nav" className={menuOpen ? 'nav-open' : ''} aria-label="Main navigation">
        <a href="#features" onClick={() => setMenuOpen(false)}>Why Orbit</a><a href="#workspace" onClick={() => setMenuOpen(false)}>The workspace</a><a href="#pricing" onClick={() => setMenuOpen(false)}>Plans</a><a className="button button-small" href="#get-started" onClick={() => setMenuOpen(false)}>Get in the loop ↗</a>
      </nav>
    </header>
    <main id="main">
      <section className="hero wrap" aria-labelledby="hero-title">
        <span className="eyebrow"><span className="status-dot" />{content.eyebrow}</span>
        <h1 id="hero-title">A little more space<br />for your <span>next big idea.</span></h1>
        <p>{content.description}</p>
        <div className="hero-actions"><a className="button" href="#workspace">{content.primaryCta} <span aria-hidden="true">↗</span></a><a className="text-link" href="#features">See how it works <span aria-hidden="true">↓</span></a></div>
        <div className="hero-caption"><span className="tiny-orbs" aria-hidden="true"><i /><i /><i /></span>Built for small teams with a lot on their minds.</div>
      </section>
      <section id="workspace" className="workspace-section wrap" aria-label="Interactive workspace demo">
        <div className="workspace-shell">
          <aside className="workspace-sidebar"><strong>Studio space <span>⌄</span></strong><p>YOUR WORKSPACE</p><span>◉ Overview</span><span className="active">▦ Projects <i>03</i></span><span>▤ Team notes</span><span>♡ Little wins</span><div className="sidebar-bottom"><b>M</b><span>Maya Chen<small>Studio member</small></span></div></aside>
          <div className="workspace-main"><div className="workspace-top"><span>Projects / <b>A fresh start</b></span><span className="demo-badge">Interactive sample</span></div>
            <div className="project-heading"><div><span className="eyebrow">YOUR NEXT CHAPTER</span><h2>A fresh start <span aria-hidden="true">✳</span></h2><p>A shared space for a small idea with a bright future.</p></div><span className="project-avatar" aria-label="Sample team member">M</span></div>
            <div className="project-toolbar"><div className="view-tabs" role="group" aria-label="Project view">{(['Board', 'List'] as const).map(item => <button key={item} aria-pressed={view === item} className={view === item ? 'selected' : ''} onClick={() => setView(item)}>{item === 'Board' ? '▦' : '☰'} {item}</button>)}</div><span>3 tasks · {done ? 1 : 0} complete</span></div>
            <div className={view === 'Board' ? 'task-board' : 'task-list'}>{tasks.map((task, i) => <article className="task-card" key={task}><div className="task-label"><span className={`pill pill-${i}`}>{['Exploring', 'In motion', 'Coming together'][i]}</span><span>···</span></div><div className={`task-art task-art-${i}`} aria-hidden="true"><i /><i /><i /></div><h3>{task}</h3><p>{['A few sparks to get us started.', 'Great work gets better together.', 'Make it feel like us.'][i]}</p><div className="task-bottom">{i === 0 ? <button className={done ? 'task-check checked' : 'task-check'} aria-pressed={done} onClick={() => setDone(!done)}>{done ? '✓ Done' : '○ Mark done'}</button> : <span>↗ {['', '2 notes', '3 details'][i]}</span>}<b>{['M', 'J', 'A'][i]}</b></div></article>)}</div>
          </div>
        </div><p className="workspace-caption">Try the board view and task checkbox. Changes stay in this preview session.</p>
      </section>
      <section id="features" className="features-section wrap"><div className="section-heading"><span className="eyebrow">A CLEARER WAY TO WORK</span><h2>Less keeping track.<br />More moving forward.</h2><p>Good tools leave space for the people using them.</p></div><div className="feature-grid">{content.features.map(feature => <article key={feature.number}><span>{feature.number}</span><h3>{feature.title}</h3><p>{feature.body}</p></article>)}</div></section>
      <section className="statement-section"><div className="wrap statement-inner"><div className="flower" aria-hidden="true">✳</div><h2>Good work needs<br /><em>a little breathing room.</em></h2><p>A calmer canvas for your team’s next chapter.</p></div></section>
      <section id="pricing" className="pricing-section wrap"><div className="section-heading"><span className="eyebrow">ROOM TO GROW</span><h2>Start small.<br />Make something good.</h2><p>Illustrative product pricing. No checkout is connected.</p><button className="billing-toggle" aria-pressed={yearly} onClick={() => setYearly(!yearly)}><span className={yearly ? '' : 'selected'}>Monthly</span><span className={yearly ? 'selected' : ''}>Yearly · save 20%</span></button></div><article className="pricing-card"><span className="eyebrow">THE STUDIO PLAN · SAMPLE</span><h3>For your next big idea.</h3><p><strong>${yearly ? '12' : '15'}</strong> / person / month</p><small>{yearly ? '$144 per person, billed yearly' : 'Billed monthly'}</small><ul><li>One home for all your projects</li><li>Notes that stay with the work</li><li>A little more clarity, every day</li></ul><a className="button" href="#get-started">Explore the demo <span aria-hidden="true">↗</span></a></article></section>
      <section className="faq-section wrap"><div className="section-heading"><span className="eyebrow">A FEW GOOD QUESTIONS</span><h2>Before you<br />make yourself at home.</h2></div><div className="faqs">{content.faqs.map((faq, i) => <article key={faq.question}><h3><button aria-expanded={openFaq === i} aria-controls={`faq-${i}`} onClick={() => setOpenFaq(openFaq === i ? null : i)}>{faq.question}<span aria-hidden="true">{openFaq === i ? '−' : '+'}</span></button></h3><div id={`faq-${i}`} hidden={openFaq !== i}><p>{faq.answer}</p></div></article>)}</div></section>
      <section id="get-started" className="signup-section wrap"><span className="eyebrow">THE NEXT CHAPTER STARTS HERE</span><h2>Make room for<br /><span>something good.</span></h2><form onSubmit={event => { event.preventDefault(); setSubmitted(true) }}><label className="sr-only" htmlFor="email">Your work email</label><input id="email" type="email" autoComplete="email" placeholder="Your work email" value={email} onChange={event => { setEmail(event.target.value); setSubmitted(false) }} required /><button className="button" type="submit">Try the form ↗</button></form><p role="status">{submitted ? `Looks good — ${email} is valid. This sample does not send or store your email.` : 'Demo form only. No email is sent or saved.'}</p></section>
    </main>
    <footer className="site-footer wrap"><a className="wordmark" href="#"><span className="brand-orb" aria-hidden="true">✳</span>{content.brand}.</a><p>Made for a little more possibility.</p><span>LOOKFILE · Free source sample · 2026</span></footer>
  </>
}
