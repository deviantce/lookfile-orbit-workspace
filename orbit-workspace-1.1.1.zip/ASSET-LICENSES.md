# Asset records

The original source, CSS illustrations, demo content and accompanying documents in this **free sample** use the MIT license in `LICENSE.md`. The fictional names and task data do not refer to real customer testimonials.

No font file is bundled. The browser uses its installed Arial/Helvetica/sans-serif fonts. Decorative shapes are original CSS. Unicode symbols are rendered by the user's system font; no icon library or icon file is redistributed.

`design/asset-manifest.json` records the included artwork. Dependencies are declared in `package.json` and pinned in `package-lock.json`; `node_modules` is not distributed. Installed dependencies retain their own license notices. This sample's MIT license does not set the terms for future paid LOOKFILE kits, third-party libraries, or customers' own brand assets.

<!-- BRAND-SYSTEM-NOTICES:START -->
## Brand-system additions

`public/brand/index.html` documents the actual kit identity with editable data, 12 original SVG icons, 6 manually controlled motion studies, identity variants and source-token snapshots. New extensions and existing-runtime cues are labelled separately. Original files and existing website layouts were preserved. These additions use the same MIT as the kit's original material; underlying font glyphs retain their separate OFL notices. No system-font binaries or third-party icon package is redistributed. See `public/brand/asset-ledger.json` for the itemized SHA-256 inventory and `public/brand/README.txt` for the editing map.
<!-- BRAND-SYSTEM-NOTICES:END -->
