# Changelog

## 1.0.0 — 2026-09-25

Initial Orbit Workspace free technical sample. Complete responsive React source, working local demo controls, AI Playbook, design context, and standalone packaging pipeline.

## 1.1.1 — 2026-10-03

- Add a complete visual brand system at `/brand/`, with editable SVG icons and motion patterns.
- Preserve the existing website and earlier immutable release artifacts.
