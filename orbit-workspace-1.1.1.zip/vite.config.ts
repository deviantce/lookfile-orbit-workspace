import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Factory previews pass --base=/kits/<slug>/<version>/.
// The downloaded customer project stays deployable at a chosen relative path.
export default defineConfig({ plugins: [react()], base: './' })
