# Release checklist

Automated gates:
- Manifest, pinned stack, required delivery files and local asset rights records validate.
- Source passes `npm run verify`.
- Buyer ZIP excludes node_modules, environment files, secrets, internal research and build output.
- ZIP extracts into a clean directory; `npm ci` and `npm run verify` pass without the production workspace.
- SHA256 and size match the immutable release record.

Visual and interaction review to record for each changed release:
- 390 / 768 / 1440 CSS pixel widths; no page overflow or unreadable body copy.
- Mobile menu, all anchors, board/list toggle, task checkbox, pricing toggle and FAQs.
- Keyboard focus, field labels, email validation, honest local-only submission message.
- Reduced motion; no console error or broken asset URL under the versioned preview path.
- Brand copy, content completeness, new asset rights, third-party notices and compatibility claims.

AI editing evaluation remains a separate task: save the tool/model/version, the exact prompt, output changes, repair steps and result. A build pass alone is not an AI editing benchmark or approval to sell a paid product.

## Brand system edition

- [ ] Open `/brand/` directly and through the store Brand system button; reload both addresses.
- [ ] Match the public JSON slug/releaseVersion, colors and fonts to the exact kit release.
- [ ] Inspect identity variants, color contrast, type scale, spacing/layout and component states.
- [ ] Search all 12 original SVG icons, copy/view vector source and try the clipboard fallback.
- [ ] Play, pause and replay the six motion studies; verify system and manual reduced motion.
- [ ] Check typography specimen editing, component feedback and mobile section navigation.

Executed authoring checks for this edition are in `brand-system-review.md`.
